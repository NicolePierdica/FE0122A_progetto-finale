import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth/auth.service';

@Component({
  selector: 'app-navbar',
  template: `
    <nav>

    <div class="title-bar">
  <div class="title-bar-text">CRM-fatture</div>
  <div class="title-bar-controls">
    <button aria-label="Minimize"></button>
    <button aria-label="Maximize"></button>
    <button aria-label="Close"></button>
  </div>
</div>
    <div class="container-fluid">


      <div class="window" id="navbarTogglerDemo01">
        <ul class="navbar">






          <li *ngIf="!isLoggedIn" class="nav-item">
            <a
              class="nav-link"
              [routerLink]="['/login']"
              routerLinkActive="active"
              [routerLinkActiveOptions]="{ exact: true }"
              >
              <button class="nav-button">Login</button>
              </a
            >
          </li>

          <li *ngIf="!isLoggedIn" class="nav-item">

            <a
              class="nav-link"
              [routerLink]="['/signup']"
              routerLinkActive="active"
              [routerLinkActiveOptions]="{ exact: true }"
              ><button class="nav-button">Signup</button></a
            >

          </li>

          <li *ngIf="isLoggedIn" class="nav-item">
            <a
              class="nav-link"
              [routerLink]="['/utenti']"
              routerLinkActive="active"
              [routerLinkActiveOptions]="{ exact: true }"
              ><button class="nav-button">Users</button></a
            >
          </li>
          <li *ngIf="isLoggedIn" class="nav-item">
            <a
              class="nav-link"
              [routerLink]="['/clienti']"
              routerLinkActive="active"
              [routerLinkActiveOptions]="{ exact: true }"
              ><button class="nav-button">Clients</button></a>

          </li>
          <li *ngIf="isLoggedIn" class="nav-item">
            <a
              class="nav-link"
              [routerLink]="['/fatture']"
              routerLinkActive="active"
              [routerLinkActiveOptions]="{ exact: true }"
              ><button class="nav-button">Invoices</button></a
            >
          </li>
        </ul>
        <div *ngIf="isLoggedIn" class="ms-auto">
          <p class="username-welc-back">Welcome back: <span class="fst-italic fw-bolder"><br>{{currentUser}}</span></p>
          <button class="button" (click)="onLogout()">

        logout<img src="assets/img_98/red-button.png" alt="logout" class="logout"></button>
        </div>
      </div>
    </div>
  </nav>

  `,
  styles: [
    `.nav-item{
    list-style: none;
    display: inline-block;
    justify-content: space-between;


    }


    img.logout{
     height: 13px;
    }

    .username-welc-back{
      display: flex;
      justify-content: flex-end;
      margin-right: 10px;
    }





    `]
})
export class NavbarComponent implements OnInit {
  isLoggedIn: boolean = false;

  constructor(private authSrv: AuthService) { }

  ngOnInit(): void {
    this.authSrv.isLoggedIn$.subscribe((isLoggedIn) => {
      this.isLoggedIn = isLoggedIn;
    })
  }

  onLogout() {
    this.authSrv.logout();
  }

  get currentUser() {
    const userJson = localStorage.getItem('user');
    if (!userJson) {
      return;
    }
    const user = JSON.parse(userJson);
    return user.username;
  }

  
}
