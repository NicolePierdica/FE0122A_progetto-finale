import { Component, OnInit } from "@angular/core";
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { AuthService } from "./auth.service";

@Component({
  template: `
    <div class="container-fluid">
        <div class="window" style="width: 300px">
  <div class="title-bar">
    <div class="title-bar-text">Welcome</div>
    <div class="title-bar-controls">
      <button aria-label="Minimize"></button>
      <button aria-label="Maximize"></button>
      <button aria-label="Close"></button>
    </div>

  </div>
  <div class="window-body">
    <p>This is a beta V 0.0.1 of a collecting receipts program.<br>Please Sign-Up to test if this can work for your company.</p>
  </div>

    <div class="container mt-5 text-center p-5">
      <div class="row">
        <div class="col">
          <div *ngIf="errorMessage" class="alert alert-danger" role="alert">
            {{errorMessage}}
          </div>
          <form [formGroup]="form" (ngSubmit)="onSubmit(form)">
            <div class="form-group mb-4">
              <label for="username" class="mb-2">Username</label>
              <input type="text" formControlName="username" id="username" class="form-control">
              <span *ngIf="!form.controls['username'].valid && form.controls['username']?.touched" class="text-danger">
                <ng-container *ngIf="getErrorController('username', 'required')">Write a username!</ng-container>
              </span>
            </div>
            <div class="form-group mb-4">
                <label for="email">Email</label>
                <input type="email" formControlName="email" id="email" class="form-control">
                <span *ngIf="!form.controls['email'].valid && form.controls['email']?.touched" class="text-danger">
                  <ng-container *ngIf="getErrorController('email', 'required')">Write an email!</ng-container>
                </span>
            </div>
            <div class="form-group mb-4">
              <label for="password" class="mb-2">Password</label>
              <input type="password" formControlName="password" id="password" class="form-control">
              <span *ngIf="!form.controls['password'].valid && form.controls['password']?.touched" class="text-danger">
                <ng-container *ngIf="getErrorController('password', 'required')" class="text-danger">Write a password!</ng-container>
              </span>
            </div>
            <div class="form-group mb-4">
              <label for="nome" class="mb-2">Name</label>
              <input type="text" formControlName="nome" id="nome" class="form-control">
              <span *ngIf="!form.controls['nome'].valid && form.controls['nome']?.touched" class="text-danger">
                <ng-container *ngIf="getErrorController('nome', 'required')">Write a name!</ng-container>
              </span>
            </div>
            <div class="form-group mb-4">
              <label for="cognome" class="mb-2">Surname</label>
              <input type="text" formControlName="cognome" id="cognome" class="form-control">
              <span *ngIf="!form.controls['cognome'].valid && form.controls['cognome']?.touched" class="text-danger">
                <ng-container *ngIf="getErrorController('cognome', 'required')">Write a surname!</ng-container>
              </span>
            </div>
            <div class="form-group mb-4" formArrayName="role">
              <label for="role" class="mb-2">Role</label>
              <div *ngFor="let r of getRole(); let i = index">
                <select [formControlName]="i" class="select" aria-label="Default select example">
                  
                  <option value="admin">Admin</option>
                  <option value="user">User</option>
                </select>
              </div>
              <span *ngIf="!form.controls['role'].valid && form.controls['role'].touched" class="text-danger">
                Select a role!
              </span>
            </div>
            <button type="submit" class="button" [disabled]="form.status == 'INVALID' ? true : false">
              <div *ngIf="isLoading; else elseText" class="spinner-border text-light" role="status">
                <span class="visually-hidden">Loading...</span>
              </div>
              <ng-template #elseText>Sign Up</ng-template>
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>

  `,
  styles: [`
  .container-fluid{
    display: flex;
    justify-content: center;
    margin-top: 100px;
    margin-bottom: 50px;
  }
    .container{
      display: flex;
      justify-content: center;
    }

  `],
})
export class SignupPage implements OnInit {
  form!: FormGroup;
  errorMessage = undefined;
  isLoading: boolean = false;

  constructor(private authSrv: AuthService, private router: Router, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      username: this.fb.control(null, Validators.required),
      password: this.fb.control(null, Validators.required),
      email: this.fb.control(null, [Validators.required, Validators.email]),
      nome: this.fb.control(null, Validators.required),
      cognome: this.fb.control(null, Validators.required),
      role: this.fb.array([], Validators.required)
    })

    this.addSelectRole();
  }

  async onSubmit(form: FormGroup) {
    this.isLoading = true;

    try {
      await this.authSrv.signup(form.value).toPromise();
      form.reset();
      this.errorMessage = undefined
      this.router.navigate(['/login'])
    } catch (error:any) {
      this.isLoading = false
      this.errorMessage = error
      console.error(error);
    }
  }

  addSelectRole() {
    const control = new FormControl(null, Validators.required);
    (this.form.get('role') as FormArray).push(control);
  }

  getRole() {
    return (this.form.get('role') as FormArray).controls;
  }

  getErrorController(name: string, error: string) {
    return this.form.get(name)?.errors![error];
  }
}
