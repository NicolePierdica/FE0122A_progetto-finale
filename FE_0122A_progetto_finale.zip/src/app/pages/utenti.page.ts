import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UsersService } from '../services/users.service';

@Component({
  template: `
    <div class="container-fluid">
  <div class="window" style="width: auto">
  <div class="title-bar">
    <div class="title-bar-text">Users</div>
    <div class="title-bar-controls">
      <button aria-label="Minimize"></button>
      <button aria-label="Maximize"></button>
      <button aria-label="Close"></button>
    </div>
  </div>
  <div class="window-body">



    <table class="table">
      <thead>
        <tr>
          <th scope="col">id</th>
          <th scope="col">Username</th>
          <th scope="col">Name</th>
          <th scope="col">Surname</th>
          <th scope="col">Email</th>
          <th scope="col">Role</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let user of users">
          <td>{{user.id}}</td>
          <td>{{user.username}}</td>
          <td>{{user.nome}}</td>
          <td>{{user.cognome}}</td>
          <td>{{user.email}}</td>
          <td><span *ngFor="let item of user.roles">{{item.roleName}}</span></td>
        </tr>
      </tbody>
  </table>
  <nav aria-label="Page navigation example">
    <ul class="pagination">
      <li class="page-item" (click)="goToPage(0)"><a class="link-page"><button><-First</button></a></li>
      <li *ngIf="!response.first; " class="page-item" (click)="goToPage(response.number - 1)"><a class="link-pagek"><button>Previous</button></a></li>
      <!-- <li *ngFor="let page of pages" class="page-item" (click)="goToPage(page)"><a [ngClass]="{'active-pagination' : page == response.number}" class="page-link">{{page + 1}}</a></li> -->
      <ng-container *ngFor="let page of pages">
        <li *ngIf="page < response.number + 5 && page > response.number - 5" class="page-item" (click)="goToPage(page)"><a [ngClass]="{'active-pagination' : page == response.number}" class="link-page">{{page + 1}}</a></li>
      </ng-container>
      <li *ngIf="!response.last;" class="page-item" (click)="goToPage(response.number + 1)"><a class="link-page"><button>Next</button></a></li>
      <li class="page-item" (click)="goToPage(response.totalPages - 1)"><a class="link-page"><button>Last-></button></a></li>

    </ul>
  </nav>
  </div>
</div>
</div>
  `,
  styles: [`

    .container-fluid {
      display: flex;
      justify-content: center;
      margin-top: 10px;
      margin-bottom: 50px;

    }


    .pagination li {
      cursor: pointer;
      display: inline-block;
      padding: 6px;

      

    }


  `]
})
export class UtentiPage implements OnInit {
  users!: User[];
  response!: any;
  pages: number[] = [];

  constructor(private usersSrv: UsersService) {
  }

  ngOnInit(): void {
    this.usersSrv.getAllUsers(0).subscribe(res => {
      this.users = res.content;
      this.response = res;
      this.pages = Array(this.response.totalPages).fill(0).map((x, i) => i)
    })
  }

  goToPage(page: number) {
    this.users.length = 0;
    this.usersSrv.getAllUsers(page).subscribe(res => {
      this.users = res.content;
      this.response = res;
    })
  }
}
