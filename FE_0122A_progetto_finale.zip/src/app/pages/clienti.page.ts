import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth/auth.service';
import { ClientiService } from '../services/clienti.service';
import { FattureService } from '../services/fatture.service';

@Component({
  template: `
  <div class="container-fluid">
  <div class="window" style="width: auto">
  <div class="title-bar">
    <div class="title-bar-text">Clients</div>
    <div class="title-bar-controls">
      <button aria-label="Minimize"></button>
      <button aria-label="Maximize"></button>
      <button aria-label="Close"></button>
    </div>
  </div>
  <div class="window-body">
    <table class="table">
      <thead>
        <tr>
          <th scope="col">id</th>
          <th scope="col">Ragione Sociale</th>
          <th scope="col">Email</th>
          <th scope="col">Partita Iva</th>
          <th scope="col"><button [ngClass]="{'disabled cursor-disabled' : tipoUser == 'ROLE_USER'}" type="button" class="button" (click)="tipoUser == 'ROLE_ADMIN' ? newCliente() : false">New client</button></th>
          <th scope="col"><button type="button" (click)="goToPage(0)" class="button">Refresh page</button></th>
          <th scope="col"></th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let cliente of response.content; let i = index">
          <td>{{cliente.id}}</td>
          <td>{{cliente.ragioneSociale}}</td>
          <td>{{cliente.email}}</td>
          <td>{{cliente.partitaIva}}</td>
          <td><button type="button" (click)="goFattureCliente(cliente.id)" class="button">Invoices</button></td>
          <td><button type="button" (click)="tipoUser == 'ROLE_ADMIN' ? updateCliente(cliente.id) : false" class="button" [ngClass]="{'disabled cursor-disabled' : tipoUser == 'ROLE_USER'}">Modify</button></td>
          <td><button type="button" (click)="tipoUser == 'ROLE_ADMIN' ? getIndexId(cliente.id, i) : false" class="button" [ngClass]="{'disabled cursor-disabled' : tipoUser == 'ROLE_USER'}" data-bs-toggle="modal" data-bs-target="#exampleModal"><img src="assets/img_98/red-button.png" alt="logout" class="logout">Delete</button></td>
        </tr>
      </tbody>
  </table>




  <nav aria-label="page navigation example">
    <ul class="pagination">
      <li class="page-item" (click)="goToPage(0)"><a class="link-page"><button><-First</button></a></li>
      <li *ngIf="!response.first;" class="page-item" (click)="goToPage(response.number - 1)"><a class="link-page"><button>Previous</button></a></li>
      <ng-container *ngFor="let page of pages">
        <li *ngIf="page < response.number + 5 && page > response.number - 5" class="page-item" (click)="goToPage(page)"><a [ngClass]="{'active-pagination' : page == response.number}" class="link-page">{{page + 1}}</a></li>
      </ng-container>
      <li *ngIf="!response.last;" class="page-item" (click)="goToPage(response.number + 1)"><a class="link-page"><button>Next</button></a></li>
      <li class="page-item" (click)="goToPage(response.totalPages - 1)"><a class="link-page"><button>Last-></button></a></li>

    </ul>
  </nav>
  </div>
  </div>
  </div>



  <!-- Modale -->


  <div *ngIf="tipoUser == 'ROLE_ADMIN'" class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Are you sure you want to delete this client?</h5>

        </div>
        <div class="modal-body">
          <p class="text-danger">No reversible command </p>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal" (click)="tipoUser == 'ROLE_ADMIN' ? removeCliente(clienteCorrente[0], clienteCorrente[1]) : false">Delete</button>
        </div>
      </div>

    </div>


  `,
  styles: [`
    .container-fluid {
      display: flex;
      justify-content: center;
      margin-top: 10px;
      margin-bottom: 50px;

    }




    .pagination li {
      cursor: pointer;
      display: inline-block;
      padding: 6px;

    }


    .cursor-disabled {
      cursor: no-drop;
      pointer-events: visible;
    }

    #exampleModal {
      text-align: center;
    }
    img.logout{
     height: 13px;
    }
  `]
})
export class ClientiPage implements OnInit {
  response!: any;
  pages: number[] = [];
  clienteCorrente: number[] = [-50, -50];

  constructor(private clientiSrv: ClientiService, private fattSrv: FattureService, private router: Router, private authSrv: AuthService) { }

  ngOnInit(): void {
    this.clientiSrv.getClienti(0).subscribe(res => {
      this.response = res;
      this.pages = Array(this.response.totalPages).fill(0).map((x, i) => i)
      console.log(this.response);

    })
  }

  goToPage(page: number) {
    this.response.content.length = 0;
    this.clientiSrv.getClienti(page).subscribe(res => {
      this.response = res;
    })
  }

  goFattureCliente(id: number) {
    this.router.navigate([`/clienti/${id}/fatture`])
  }

  newCliente() {
    this.router.navigate(["/nuovo-cliente"])
  }

  updateCliente(id: number) {
    this.router.navigate([`/clienti/${id}/modifica`])
  }

  getIndexId(id: number, index: number) {
    this.clienteCorrente = [id, index];
    console.log(this.clienteCorrente);

  }

  removeCliente(id: number, i: number) {
    this.fattSrv.deleteFattureByCliente(id).subscribe(res => {
      console.log(res);

      this.fattSrv.getFattureByCliente(id, 0).subscribe(async res => {
        const response = await res.content;
        console.log(response);

        if(response.length == 0) {
          this.clientiSrv.cancellaCliente(id).subscribe();
          this.response.content.splice(i, 1);
        } else {
          alert('Please pay attention, this client has still invoices!');
        }
      })
    });
  }

  get tipoUser(): string | undefined {
    return this.authSrv.tipoUtente;
  }
}
