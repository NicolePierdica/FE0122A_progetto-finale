
import { formatDate } from '@angular/common';
import {Component,
  Inject,
  LOCALE_ID }
  from '@angular/core';
@Component({
  selector: 'app-root',
  template: `
    <app-navbar></app-navbar>
    <router-outlet></router-outlet>


  `,
  styles: []
})
export class AppComponent {
  title = 'FE_0122A_progetto_finale';

  


  }





